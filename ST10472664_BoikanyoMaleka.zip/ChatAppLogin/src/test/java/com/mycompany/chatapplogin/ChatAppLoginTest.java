/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class ChatAppLoginTest {
    
    public ChatAppLoginTest() {
    }
    
    // --- Username Validation Tests ---
    
    @Test
    public void testValidUsername() {
        String username = "ky_1";
        boolean result = ChatAppLogin.isUsernameValid(username);
        System.out.println("Testing valid username: " + username);
        System.out.println("Username successfully captured.");
        assertTrue(result, "Expected valid username: contains '_' and ≤ 5 characters, but was invalid");
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        String username = "kyle1";
        boolean result = ChatAppLogin.isUsernameValid(username);
        System.out.println("Testing invalid username (missing underscore): " + username);
        System.out.println("Condition: Expected invalid username, missing '_'");
        assertFalse(result, "Expected invalid username: missing '_'");
    }

    @Test
    public void testInvalidUsername_TooLong() {
        String username = "ky_le!!!!!!!";
        boolean result = ChatAppLogin.isUsernameValid(username);
        System.out.println("Testing invalid username (too long): " + username);
        System.out.println("Condition: Expected invalid username, too long");
        assertFalse(result, "Expected invalid username: too long");
    }

    // --- Password Validation Tests ---
    
    @Test
    public void testValidPassword() {
        String password = "Ch&&sec@ke99!";
        boolean result = ChatAppLogin.isPasswordValid(password);
        System.out.println("Testing valid password: " + password);
        System.out.println("Condition: Expected valid password, meets complexity requirements");
        assertTrue(result, "Expected valid password: meets complexity requirements");
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        String password = "Cheese99";
        boolean result = ChatAppLogin.isPasswordValid(password);
        System.out.println("Testing invalid password (no special character): " + password);
        System.out.println("Condition: Expected invalid password, missing special character");
        assertFalse(result, "Expected invalid password: missing special character");
    }

    @Test
    public void testInvalidPassword_NoDigit() {
        String password = "Cheese@@@";
        boolean result = ChatAppLogin.isPasswordValid(password);
        System.out.println("Testing invalid password (no digit): " + password);
        System.out.println("Condition: Expected invalid password, no digit");
        assertFalse(result, "Expected invalid password: no digit");
    }

    @Test
    public void testInvalidPassword_NoUpperCase() {
        String password = "cheese@99";
        boolean result = ChatAppLogin.isPasswordValid(password);
        System.out.println("Testing invalid password (no uppercase letter): " + password);
        System.out.println("Condition: Expected invalid password, no uppercase letter");
        assertFalse(result, "Expected invalid password: no uppercase letter");
    }

    @Test
    public void testInvalidPassword_TooShort() {
        String password = "Ch@1x";
        boolean result = ChatAppLogin.isPasswordValid(password);
        System.out.println("Testing invalid password (too short): " + password);
        System.out.println("Condition: Expected invalid password, too short");
        assertFalse(result, "Expected invalid password: too short");
    }

    // --- Phone Number Validation Tests ---
    
    @Test
    public void testValidPhoneNumber() {
        String phoneNumber = "+27831234567";
        boolean result = ChatAppLogin.isPhoneNumberValid(phoneNumber);
        System.out.println("Testing valid phone number: " + phoneNumber);
        System.out.println("Condition: Expected valid phone number, correct format and length");
        assertTrue(result, "Expected valid phone number: correct format and length");
    }

    @Test
    public void testInvalidPhoneNumber_WrongFormat() {
        String phoneNumber = "0831234567";
        boolean result = ChatAppLogin.isPhoneNumberValid(phoneNumber);
        System.out.println("Testing invalid phone number (wrong format): " + phoneNumber);
        System.out.println("Condition: Expected invalid phone number, missing country code (+27)");
        assertFalse(result, "Expected invalid phone number: missing country code (+27)");
    }

    @Test
    public void testInvalidPhoneNumber_TooShort() {
        String phoneNumber = "+27123";
        boolean result = ChatAppLogin.isPhoneNumberValid(phoneNumber);
        System.out.println("Testing invalid phone number (too short): " + phoneNumber);
        System.out.println("Condition: Expected invalid phone number, too short");
        assertFalse(result, "Expected invalid phone number: too short");
    }

    // Login Tests
    
    @Test
    public void testLoginSuccess() {
        boolean result = ChatAppLogin.login("user_1", "P@ssw0rd", "user_1", "P@ssw0rd");
        System.out.println("Testing successful login with username: user_1 and password: P@ssw0rd");
        System.out.println("Condition: Expected successful login, valid username and password");
        assertTrue(result, "Expected successful login: valid username and password");
    }

    @Test
    public void testLoginFailure_WrongPassword() {
        boolean result = ChatAppLogin.login("user_1", "WrongPass", "user_1", "P@ssw0rd");
        System.out.println("Testing failed login (wrong password): username=user_1, password=WrongPass");
        System.out.println("Condition: Expected failed login, wrong password");
        assertFalse(result, "Expected failed login: wrong password");
    }

    @Test
    public void testLoginFailure_WrongUsername() {
        boolean result = ChatAppLogin.login("wrong_user", "P@ssw0rd", "user_1", "P@ssw0rd");
        System.out.println("Testing failed login (wrong username): username=wrong_user, password=P@ssw0rd");
        System.out.println("Condition: Expected failed login, wrong username");
        assertFalse(result, "Expected failed login: wrong username");
    }

    // --- Main Method Execution ---
    
    @Test
    public void testMainMethodRuns() {
        System.out.println("Testing main method execution...");
        assertDoesNotThrow(() -> ChatAppLogin.main(new String[]{}), 
            "Expected main method to run without exception");
    }
}
