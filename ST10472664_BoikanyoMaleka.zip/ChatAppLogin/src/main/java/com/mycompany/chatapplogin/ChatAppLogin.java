/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class ChatAppLogin {

    // Method to validate the username
    public static boolean isUsernameValid(String username) {
        return username.contains("_") && 
                username.length() <= 5;
    }

    // Method to validate the password
    public static boolean isPasswordValid(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[^a-zA-Z0-9].*");
    }

    // Method to validate the phone number
    public static boolean isPhoneNumberValid(String phoneNumber) {
        return phoneNumber.matches("\\+27\\d{9}");
    }

    // Method to validate login
    public static boolean login(String inputUsername, String inputPassword, String registeredUsername, String registeredPassword) {
        return inputUsername.equals(registeredUsername) && inputPassword.equals(registeredPassword);
    }

    // Main method for registration and login
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- Variable Declarations ---
        String registeredUsername = "";
        String registeredPassword = "";
        String registeredPhoneNumber = "";
        String registeredFirstName = "";
        String registeredLastName = "";

        int attempts = 0;
        int maxAttempts = 3;
        boolean isLoggedIn = false;

        System.out.println("***    REGISTRATION PAGE   ***");

        //Register the user
        System.out.print("Enter username: ");
        registeredUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        registeredPassword = scanner.nextLine();

        System.out.print("Enter South African phone number: ");
        registeredPhoneNumber = scanner.nextLine();

        System.out.print("Enter your first name: ");
        registeredFirstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        registeredLastName = scanner.nextLine();

        // --- Validation ---
        boolean isUsernameValid = isUsernameValid(registeredUsername);
        boolean isPasswordValid = isPasswordValid(registeredPassword);
        boolean isPhoneValid = isPhoneNumberValid(registeredPhoneNumber);

        if (isUsernameValid) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted. Please ensure that it contains an underscore and is no more than five characters.");
        }

        if (isPasswordValid) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted; it must be at least 8 characters, contain a capital letter, a number, and a special character.");
        }

        if (isPhoneValid) {
            System.out.println("Phone number successfully captured.");
        } else {
            System.out.println("Cell phone number incorrectly formatted or missing international code.");
        }

        if (isUsernameValid && isPasswordValid && isPhoneValid) {
            System.out.println("\nRegistration successful!");
            System.out.println("Please log in to continue.\n");
        } else {
            System.out.println("\nRegistration failed due to invalid inputs. Please restart the application.");
            scanner.close();
            return; 
        }

        // Login
        while (attempts < maxAttempts && !isLoggedIn) {
            System.out.print("Enter username: ");
            String inputUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String inputPassword = scanner.nextLine();

            if (login(inputUsername, inputPassword, registeredUsername, registeredPassword)) {
                System.out.println("Welcome " + registeredFirstName + " " + registeredLastName + ", it is great to see you again!");
                isLoggedIn = true;
            } else {
                attempts++;
                int remaining = maxAttempts - attempts;
                if (remaining > 0) {
                    System.out.println("Incorrect username or password. Attempts remaining: " + remaining);
                }
            }
        }

        if (!isLoggedIn) {
            System.out.println("Too many failed login attempts. Access denied.");
        }

        scanner.close();
    }
}



    

